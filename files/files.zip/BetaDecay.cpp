#include "BetaDecay.h"
#include "G4Event.hh"
#include "G4ParticleTable.hh"
#include "G4IonTable.hh"
#include "G4Electron.hh"
#include "G4Positron.hh"
#include "G4NeutrinoE.hh"
#include "G4AntiNeutrinoE.hh"
#include "G4PhysicalConstants.hh"
#include "G4SystemOfUnits.hh"
#include "Randomize.hh"
#include <cmath>
#include <iostream>

//==============================================================================
// DecayEvent Implementation
//==============================================================================

void DecayEvent::Print() const {
    G4cout << "\n" << G4String(70, '=') << G4endl;
    G4cout << "Beta Decay Event" << G4endl;
    G4cout << G4String(70, '=') << G4endl;
    
    G4cout << "Decay Type: " << BetaDecayUtils::DecayTypeToString(decayType) << G4endl;
    G4cout << "Parent: Z=" << parentNucleus.Z << ", A=" << parentNucleus.A 
           << " (" << parentNucleus.name << ")" << G4endl;
    G4cout << "Daughter: Z=" << daughterNucleus.Z << ", A=" << daughterNucleus.A 
           << " (" << daughterNucleus.name << ")" << G4endl;
    G4cout << "Q-value: " << qValue << " MeV" << G4endl;
    G4cout << "\nDecay Products:" << G4endl;
    
    for (size_t i = 0; i < particles.size(); ++i) {
        G4cout << "  " << particles[i].particleName 
               << " - Energy: " << particles[i].energy << " MeV"
               << " - Direction: " << particles[i].direction << G4endl;
    }
    
    G4cout << "Total Energy: " << GetTotalEnergy() << " MeV" << G4endl;
    G4cout << G4String(70, '=') << G4endl;
}

G4double DecayEvent::GetTotalEnergy() const {
    G4double total = 0.0;
    for (const auto& particle : particles) {
        total += particle.energy;
    }
    return total;
}

//==============================================================================
// BetaDecayPrimaryGenerator Implementation
//==============================================================================

BetaDecayPrimaryGenerator::BetaDecayPrimaryGenerator()
    : G4VUserPrimaryGeneratorAction(),
      fParticleGun(nullptr),
      fDecayType(BetaDecayType::BETA_MINUS),
      fQValue(1.0*MeV),
      fSourcePosition(0., 0., 0.)
{
    fParticleGun = new G4ParticleGun(1);
    
    // Cache particle definitions
    fElectron = G4Electron::ElectronDefinition();
    fPositron = G4Positron::PositronDefinition();
    fNeutrino = G4NeutrinoE::NeutrinoEDefinition();
    fAntiNeutrino = G4AntiNeutrinoE::AntiNeutrinoEDefinition();
    
    // Default: Carbon-14 beta decay
    SetParentNucleus(6, 14, 0.0);
    SetQValue(0.156*MeV);
}

BetaDecayPrimaryGenerator::~BetaDecayPrimaryGenerator() {
    delete fParticleGun;
}

void BetaDecayPrimaryGenerator::SetParentNucleus(G4int Z, G4int A, G4double excitation) {
    fParentNucleus.Z = Z;
    fParentNucleus.A = A;
    fParentNucleus.excitation = excitation;
    fParentNucleus.name = BetaDecayPhysics::GetElementSymbol(Z);
    
    UpdateDaughterNucleus();
}

void BetaDecayPrimaryGenerator::UpdateDaughterNucleus() {
    fDaughterNucleus = BetaDecayUtils::GetDaughterNucleus(fParentNucleus, fDecayType);
}

void BetaDecayPrimaryGenerator::GeneratePrimaries(G4Event* event) {
    // Set source position
    fParticleGun->SetParticlePosition(fSourcePosition);
    
    // Generate decay based on type
    switch (fDecayType) {
        case BetaDecayType::BETA_MINUS:
            GenerateBetaMinus(event);
            break;
        case BetaDecayType::BETA_PLUS:
            GenerateBetaPlus(event);
            break;
        case BetaDecayType::ELECTRON_CAPTURE:
            GenerateElectronCapture(event);
            break;
        case BetaDecayType::DOUBLE_BETA_MINUS:
            GenerateDoubleBetaMinus(event);
            break;
        case BetaDecayType::DOUBLE_BETA_PLUS:
            GenerateDoubleBetaPlus(event);
            break;
        case BetaDecayType::DOUBLE_BETA_0NU:
            GenerateDoubleBeta0Nu(event);
            break;
        default:
            G4cerr << "Unknown decay type!" << G4endl;
            break;
    }
}

//==============================================================================
// Single Beta Decay Implementations
//==============================================================================

void BetaDecayPrimaryGenerator::GenerateBetaMinus(G4Event* event) {
    // Sample electron energy from beta spectrum
    G4double electronEnergy = SampleBetaSpectrum(fQValue/MeV, fParentNucleus.Z);
    electronEnergy *= MeV;
    
    // Neutrino gets remaining energy
    G4double neutrinoEnergy = fQValue - electronEnergy;
    
    // Generate random directions
    G4ThreeVector electronDir = G4RandomDirection();
    G4ThreeVector neutrinoDir = -electronDir; // Back-to-back for momentum conservation (simplified)
    
    // Generate electron
    fParticleGun->SetParticleDefinition(fElectron);
    fParticleGun->SetParticleEnergy(electronEnergy);
    fParticleGun->SetParticleMomentumDirection(electronDir);
    fParticleGun->GeneratePrimaryVertex(event);
    
    // Generate antineutrino
    fParticleGun->SetParticleDefinition(fAntiNeutrino);
    fParticleGun->SetParticleEnergy(neutrinoEnergy);
    fParticleGun->SetParticleMomentumDirection(neutrinoDir);
    fParticleGun->GeneratePrimaryVertex(event);
}

void BetaDecayPrimaryGenerator::GenerateBetaPlus(G4Event* event) {
    // Available energy after accounting for positron mass
    G4double availableEnergy = fQValue - 2.0 * CLHEP::electron_mass_c2;
    
    if (availableEnergy <= 0) {
        G4cerr << "Beta plus decay not energetically allowed!" << G4endl;
        return;
    }
    
    // Sample positron energy
    G4double positronEnergy = SampleBetaSpectrum(availableEnergy/MeV, -fParentNucleus.Z);
    positronEnergy *= MeV;
    
    // Neutrino gets remaining energy
    G4double neutrinoEnergy = availableEnergy - positronEnergy;
    
    // Generate random directions
    G4ThreeVector positronDir = G4RandomDirection();
    G4ThreeVector neutrinoDir = -positronDir;
    
    // Generate positron
    fParticleGun->SetParticleDefinition(fPositron);
    fParticleGun->SetParticleEnergy(positronEnergy);
    fParticleGun->SetParticleMomentumDirection(positronDir);
    fParticleGun->GeneratePrimaryVertex(event);
    
    // Generate neutrino
    fParticleGun->SetParticleDefinition(fNeutrino);
    fParticleGun->SetParticleEnergy(neutrinoEnergy);
    fParticleGun->SetParticleMomentumDirection(neutrinoDir);
    fParticleGun->GeneratePrimaryVertex(event);
}

void BetaDecayPrimaryGenerator::GenerateElectronCapture(G4Event* event) {
    // All energy goes to neutrino (simplified - ignoring atomic binding energy)
    G4ThreeVector neutrinoDir = G4RandomDirection();
    
    fParticleGun->SetParticleDefinition(fNeutrino);
    fParticleGun->SetParticleEnergy(fQValue);
    fParticleGun->SetParticleMomentumDirection(neutrinoDir);
    fParticleGun->GeneratePrimaryVertex(event);
}

//==============================================================================
// Double Beta Decay Implementations
//==============================================================================

void BetaDecayPrimaryGenerator::GenerateDoubleBetaMinus(G4Event* event) {
    // Simplified phase space distribution for 2-neutrino mode
    // More realistic implementations would use proper matrix elements
    
    // Distribute energy among 4 particles (2 electrons + 2 antineutrinos)
    G4double e1 = G4UniformRand() * fQValue * 0.5;
    G4double e2 = G4UniformRand() * (fQValue - e1) * 0.5;
    G4double nu1 = G4UniformRand() * (fQValue - e1 - e2);
    G4double nu2 = fQValue - e1 - e2 - nu1;
    
    // Generate random directions
    G4ThreeVector dir1 = G4RandomDirection();
    G4ThreeVector dir2 = G4RandomDirection();
    G4ThreeVector dir3 = G4RandomDirection();
    G4ThreeVector dir4 = G4RandomDirection();
    
    // Electron 1
    fParticleGun->SetParticleDefinition(fElectron);
    fParticleGun->SetParticleEnergy(e1);
    fParticleGun->SetParticleMomentumDirection(dir1);
    fParticleGun->GeneratePrimaryVertex(event);
    
    // Electron 2
    fParticleGun->SetParticleEnergy(e2);
    fParticleGun->SetParticleMomentumDirection(dir2);
    fParticleGun->GeneratePrimaryVertex(event);
    
    // Antineutrino 1
    fParticleGun->SetParticleDefinition(fAntiNeutrino);
    fParticleGun->SetParticleEnergy(nu1);
    fParticleGun->SetParticleMomentumDirection(dir3);
    fParticleGun->GeneratePrimaryVertex(event);
    
    // Antineutrino 2
    fParticleGun->SetParticleEnergy(nu2);
    fParticleGun->SetParticleMomentumDirection(dir4);
    fParticleGun->GeneratePrimaryVertex(event);
}

void BetaDecayPrimaryGenerator::GenerateDoubleBetaPlus(G4Event* event) {
    // Available energy after accounting for 2 positron masses
    G4double availableEnergy = fQValue - 4.0 * CLHEP::electron_mass_c2;
    
    if (availableEnergy <= 0) {
        G4cerr << "Double beta plus decay not energetically allowed!" << G4endl;
        return;
    }
    
    // Distribute energy among 4 particles
    G4double e1 = G4UniformRand() * availableEnergy * 0.5;
    G4double e2 = G4UniformRand() * (availableEnergy - e1) * 0.5;
    G4double nu1 = G4UniformRand() * (availableEnergy - e1 - e2);
    G4double nu2 = availableEnergy - e1 - e2 - nu1;
    
    G4ThreeVector dir1 = G4RandomDirection();
    G4ThreeVector dir2 = G4RandomDirection();
    G4ThreeVector dir3 = G4RandomDirection();
    G4ThreeVector dir4 = G4RandomDirection();
    
    // Positron 1
    fParticleGun->SetParticleDefinition(fPositron);
    fParticleGun->SetParticleEnergy(e1);
    fParticleGun->SetParticleMomentumDirection(dir1);
    fParticleGun->GeneratePrimaryVertex(event);
    
    // Positron 2
    fParticleGun->SetParticleEnergy(e2);
    fParticleGun->SetParticleMomentumDirection(dir2);
    fParticleGun->GeneratePrimaryVertex(event);
    
    // Neutrino 1
    fParticleGun->SetParticleDefinition(fNeutrino);
    fParticleGun->SetParticleEnergy(nu1);
    fParticleGun->SetParticleMomentumDirection(dir3);
    fParticleGun->GeneratePrimaryVertex(event);
    
    // Neutrino 2
    fParticleGun->SetParticleEnergy(nu2);
    fParticleGun->SetParticleMomentumDirection(dir4);
    fParticleGun->GeneratePrimaryVertex(event);
}

void BetaDecayPrimaryGenerator::GenerateDoubleBeta0Nu(G4Event* event) {
    // Neutrinoless double beta decay - all energy shared between 2 electrons
    // This is the key signature: sum of electron energies = Q-value
    
    G4double e1 = G4UniformRand() * fQValue;
    G4double e2 = fQValue - e1;
    
    G4ThreeVector dir1 = G4RandomDirection();
    G4ThreeVector dir2 = G4RandomDirection();
    
    // Electron 1
    fParticleGun->SetParticleDefinition(fElectron);
    fParticleGun->SetParticleEnergy(e1);
    fParticleGun->SetParticleMomentumDirection(dir1);
    fParticleGun->GeneratePrimaryVertex(event);
    
    // Electron 2
    fParticleGun->SetParticleEnergy(e2);
    fParticleGun->SetParticleMomentumDirection(dir2);
    fParticleGun->GeneratePrimaryVertex(event);
    
    G4cout << "0νββ decay: E1=" << e1/MeV << " MeV, E2=" << e2/MeV 
           << " MeV, Sum=" << (e1+e2)/MeV << " MeV (Q=" << fQValue/MeV << " MeV)" << G4endl;
}

//==============================================================================
// Helper Functions
//==============================================================================

G4double BetaDecayPrimaryGenerator::SampleBetaSpectrum(G4double qValue, G4int Z) {
    // Rejection sampling of beta spectrum
    G4double energy = 0.0;
    G4double maxSpectrum = BetaDecayPhysics::BetaSpectrumShape(qValue/2.0, qValue, Z);
    
    G4int maxAttempts = 10000;
    for (G4int i = 0; i < maxAttempts; ++i) {
        energy = G4UniformRand() * qValue;
        G4double spectrum = BetaDecayPhysics::BetaSpectrumShape(energy, qValue, Z);
        
        if (G4UniformRand() * maxSpectrum < spectrum) {
            break;
        }
    }
    
    return energy;
}

G4double BetaDecayPrimaryGenerator::FermiFunction(G4double energy, G4int Z) {
    return BetaDecayPhysics::FermiFunction(energy, Z);
}

//==============================================================================
// BetaDecayPhysics Implementation
//==============================================================================

G4double BetaDecayPhysics::CalculateQValue(const Nucleus& parent, const Nucleus& daughter, 
                                           BetaDecayType type) {
    G4double parentMass = GetNuclearMass(parent.Z, parent.A);
    G4double daughterMass = GetNuclearMass(daughter.Z, daughter.A);
    
    G4double qValue = (parentMass - daughterMass) * MeV;
    
    // Adjust for leptons
    switch (type) {
        case BetaDecayType::BETA_MINUS:
            qValue -= ELECTRON_MASS * MeV;
            break;
        case BetaDecayType::BETA_PLUS:
            qValue -= 2.0 * ELECTRON_MASS * MeV;
            break;
        case BetaDecayType::DOUBLE_BETA_MINUS:
        case BetaDecayType::DOUBLE_BETA_0NU:
            qValue -= 2.0 * ELECTRON_MASS * MeV;
            break;
        case BetaDecayType::DOUBLE_BETA_PLUS:
            qValue -= 4.0 * ELECTRON_MASS * MeV;
            break;
        default:
            break;
    }
    
    return qValue;
}

G4bool BetaDecayPhysics::IsDecayAllowed(const Nucleus& parent, BetaDecayType type, 
                                        G4double qValue) {
    if (qValue <= 0) return false;
    
    switch (type) {
        case BetaDecayType::BETA_MINUS:
            return (parent.A - parent.Z) > 0;
        case BetaDecayType::BETA_PLUS:
        case BetaDecayType::ELECTRON_CAPTURE:
            return parent.Z > 0;
        case BetaDecayType::DOUBLE_BETA_MINUS:
        case BetaDecayType::DOUBLE_BETA_0NU:
            return (parent.A - parent.Z) >= 2;
        case BetaDecayType::DOUBLE_BETA_PLUS:
            return parent.Z >= 2;
        default:
            return false;
    }
}

G4double BetaDecayPhysics::GetNuclearMass(G4int Z, G4int A) {
    // Semi-empirical mass formula (Weizsäcker formula)
    G4int N = A - Z;
    
    G4double aV = 15.75;   // Volume term
    G4double aS = 17.8;    // Surface term
    G4double aC = 0.711;   // Coulomb term
    G4double aA = 23.7;    // Asymmetry term
    G4double aP = 11.18;   // Pairing term
    
    G4double binding = aV * A
                     - aS * std::pow(A, 2.0/3.0)
                     - aC * Z * (Z - 1) / std::pow(A, 1.0/3.0)
                     - aA * std::pow(N - Z, 2.0) / A;
    
    // Pairing term
    if (Z % 2 == 0 && N % 2 == 0) {
        binding += aP / std::sqrt(A);
    } else if (Z % 2 == 1 && N % 2 == 1) {
        binding -= aP / std::sqrt(A);
    }
    
    G4double mass = Z * PROTON_MASS + N * NEUTRON_MASS - binding;
    return mass;
}

G4double BetaDecayPhysics::BetaSpectrumShape(G4double energy, G4double qValue, G4int Z) {
    if (energy <= 0 || energy >= qValue) return 0.0;
    
    G4double pe = std::sqrt(energy * (energy + 2.0 * ELECTRON_MASS));
    G4double neutrinoEnergy = qValue - energy;
    
    G4double spectrum = pe * (energy + ELECTRON_MASS) * neutrinoEnergy * neutrinoEnergy;
    spectrum *= FermiFunction(energy, Z);
    
    return std::max(0.0, spectrum);
}

G4double BetaDecayPhysics::FermiFunction(G4double electronEnergy, G4int Z) {
    // Simplified Fermi function
    G4double pe = std::sqrt(electronEnergy * (electronEnergy + 2.0 * ELECTRON_MASS));
    G4double eta = 2.0 * M_PI * Z * ALPHA;
    
    if (pe < 0.01) return 1.0;
    
    G4double fermi = eta * pe / (1.0 - std::exp(-eta * pe));
    return std::max(0.0, fermi);
}

G4String BetaDecayPhysics::GetElementSymbol(G4int Z) {
    static const G4String elements[] = {
        "n", "H", "He", "Li", "Be", "B", "C", "N", "O", "F", "Ne",
        "Na", "Mg", "Al", "Si", "P", "S", "Cl", "Ar", "K", "Ca",
        "Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn",
        "Ga", "Ge", "As", "Se", "Br", "Kr", "Rb", "Sr", "Y", "Zr",
        "Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd", "In", "Sn",
        "Sb", "Te", "I", "Xe", "Cs", "Ba"
    };
    
    if (Z >= 0 && Z < 56) {
        return elements[Z];
    }
    return "X";
}

//==============================================================================
// Utility Functions Implementation
//==============================================================================

namespace BetaDecayUtils {

G4String DecayTypeToString(BetaDecayType type) {
    switch (type) {
        case BetaDecayType::BETA_MINUS:
            return "β⁻ decay (single)";
        case BetaDecayType::BETA_PLUS:
            return "β⁺ decay (single)";
        case BetaDecayType::ELECTRON_CAPTURE:
            return "Electron Capture";
        case BetaDecayType::DOUBLE_BETA_MINUS:
            return "ββ⁻ decay (2ν mode)";
        case BetaDecayType::DOUBLE_BETA_PLUS:
            return "ββ⁺ decay (2ν mode)";
        case BetaDecayType::DOUBLE_BETA_0NU:
            return "ββ⁻ decay (0ν mode - neutrinoless)";
        default:
            return "Unknown";
    }
}

Nucleus GetDaughterNucleus(const Nucleus& parent, BetaDecayType type) {
    Nucleus daughter;
    daughter.A = parent.A;
    daughter.excitation = 0.0;
    
    switch (type) {
        case BetaDecayType::BETA_MINUS:
            daughter.Z = parent.Z + 1;
            break;
        case BetaDecayType::BETA_PLUS:
        case BetaDecayType::ELECTRON_CAPTURE:
            daughter.Z = parent.Z - 1;
            break;
        case BetaDecayType::DOUBLE_BETA_MINUS:
        case BetaDecayType::DOUBLE_BETA_0NU:
            daughter.Z = parent.Z + 2;
            break;
        case BetaDecayType::DOUBLE_BETA_PLUS:
            daughter.Z = parent.Z - 2;
            break;
        default:
            daughter.Z = parent.Z;
    }
    
    daughter.name = BetaDecayPhysics::GetElementSymbol(daughter.Z);
    return daughter;
}

void PrintDecayInfo(const DecayEvent& event) {
    event.Print();
}

} // namespace BetaDecayUtils
